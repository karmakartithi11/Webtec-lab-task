<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<style type="text/css">
		body{
			background-color: lightskyblue ;
		}
	</style>
	<title>NOTICE</title>


</head>
<body>
    <h1>NO notice today</h1>
</body>
</html>