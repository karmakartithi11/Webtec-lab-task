    <footer>
        <p>&copy;Nadims</p>
    </footer>
</body>
</html